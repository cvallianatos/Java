/*
 * $Id: FactoryConfigurationError.java,v 1.3 2001/11/02 21:40:25 db Exp $
 * Copyright (C) 2001 Andrew Selkirk
 * 
 * This file is part of GNU JAXP, a library.
 *
 * GNU JAXP is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * GNU JAXP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * As a special exception, if you link this library with other files to
 * produce an executable, this library does not by itself cause the
 * resulting executable to be covered by the GNU General Public License.
 * This exception does not however invalidate any other reasons why the
 * executable file might be covered by the GNU General Public License. 
 */

package javax.xml.parsers;

/**
 * FactoryConfigurationError
 * @author	Andrew Selkirk
 * @version	1.0
 */
public class FactoryConfigurationError extends Error {

	//-------------------------------------------------------------
	// Variables --------------------------------------------------
	//-------------------------------------------------------------

	private Exception	exception	= null;


	//-------------------------------------------------------------
	// Initialization ---------------------------------------------
	//-------------------------------------------------------------
	public FactoryConfigurationError() {
		super();
	} // FactoryConfigurationError()

	public FactoryConfigurationError(String msg) {
		super(msg);
	} // FactoryConfigurationError()

	public FactoryConfigurationError(Exception ex) {
		super();
		exception = ex;
	} // FactoryConfigurationError()

	public FactoryConfigurationError(Exception ex, String msg) {
		super(msg);
		exception = ex;
	} // FactoryConfigurationError()


	//-------------------------------------------------------------
	// Methods ----------------------------------------------------
	//-------------------------------------------------------------

	public String getMessage() {
		return super.getMessage();
	} // getMessage()

	public Exception getException() {
		return exception;
	} // getException()


} // FactoryConfigurationError


